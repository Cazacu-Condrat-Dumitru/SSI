﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void encriptBtn_Click(object sender, EventArgs e)
        {
            char[] keyword = keyTextBox.Text.ToCharArray();
            int[] numbers = new int[keyTextBox.TextLength];
            Dictionary<int, string> data = new Dictionary<int, string>(); 
            string phraze = originalTextBox.Text.Replace(" ", "*");
            try
            {
                for (int i = 0; i < keyword.Length; i++)
                {
                    keyword[i] = Char.ToLower(keyword[i]);
                    for (int x = 97; x <= 122; x++)
                    {
                        if ((int)keyword[i] == x)
                        {
                            numbers[i] = x - 96;
                            data.Add(numbers[i], Convert.ToString(phraze[i]));
                        }
                    }
                }
                int counter = 0;
                for (int i = data.Count; i < phraze.Length; i++)
                {
                    if (counter == numbers.Length)
                    {
                        counter = 0;
                    }
                    data[numbers[counter]] += Convert.ToString(phraze[i]);

                    counter++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                originalTextBox.Text = "ERROR";
                Application.Restart();
                
            }

            foreach (KeyValuePair<int, string> c in data.OrderBy(x => x.Key))
            {
                encriptTextBox.Text += c.Value + "_";
            }
        }

        private void decriptBtn_Click(object sender, EventArgs e)
        {
            char[] keyword = keyTextBox.Text.ToCharArray();
            int[] numbers = new int[keyTextBox.TextLength];

            Dictionary<int, string> data = new Dictionary<int, string>(); 
            string phraze = encriptTextBox.Text.Replace("*", " ");
            string[] words = encriptTextBox.Text.Replace("*", " ").Split("_");

            try
            {
                for (int i = 0; i < keyword.Length; i++)
                {
                    keyword[i] = Char.ToLower(keyword[i]);
                    for (int x = 97; x <= 122; x++)
                    {
                        if ((int)keyword[i] == x)
                        {
                            numbers[i] = x - 96;
                            data.Add(numbers[i], " ");
                        }
                    }


                }
                int counter = 0;
                foreach (KeyValuePair<int, string> c in data.OrderBy(x => x.Key))
                {
                    data[c.Key] = words[counter];
                    counter++;
                }
                counter = 0;
                for (int i = 0; i < data.ElementAt(0).Value.Length; i++)
                {
                    foreach (KeyValuePair<int, string> c in data)
                    {
                        if (c.Value.Length < data.ElementAt(0).Value.Length && i == data.ElementAt(0).Value.Length - 1)
                        {
                            break;
                        }
                        originalTextBox.Text += c.Value[i];
                        counter++;
                        if (counter == numbers.Length)
                        {
                            counter = 0;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                originalTextBox.Text = "ERROR";
                Application.Restart();
                
            }
        }

        private void keyTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
