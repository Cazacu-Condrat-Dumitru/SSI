﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.keyTextBox = new System.Windows.Forms.TextBox();
            this.encriptTextBox = new System.Windows.Forms.RichTextBox();
            this.originalTextBox = new System.Windows.Forms.RichTextBox();
            this.encriptBtn = new System.Windows.Forms.Button();
            this.decriptBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // keyTextBox
            // 
            this.keyTextBox.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.keyTextBox.Location = new System.Drawing.Point(374, 247);
            this.keyTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.keyTextBox.Multiline = true;
            this.keyTextBox.Name = "keyTextBox";
            this.keyTextBox.Size = new System.Drawing.Size(223, 70);
            this.keyTextBox.TabIndex = 0;
            this.keyTextBox.TextChanged += new System.EventHandler(this.keyTextBox_TextChanged);
            // 
            // encriptTextBox
            // 
            this.encriptTextBox.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.encriptTextBox.Location = new System.Drawing.Point(39, 349);
            this.encriptTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.encriptTextBox.Name = "encriptTextBox";
            this.encriptTextBox.Size = new System.Drawing.Size(892, 189);
            this.encriptTextBox.TabIndex = 1;
            this.encriptTextBox.Text = "";
            // 
            // originalTextBox
            // 
            this.originalTextBox.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.originalTextBox.Location = new System.Drawing.Point(39, 25);
            this.originalTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.originalTextBox.Name = "originalTextBox";
            this.originalTextBox.Size = new System.Drawing.Size(892, 189);
            this.originalTextBox.TabIndex = 1;
            this.originalTextBox.Text = "";
            // 
            // encriptBtn
            // 
            this.encriptBtn.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.encriptBtn.Location = new System.Drawing.Point(39, 247);
            this.encriptBtn.Margin = new System.Windows.Forms.Padding(4);
            this.encriptBtn.Name = "encriptBtn";
            this.encriptBtn.Size = new System.Drawing.Size(308, 70);
            this.encriptBtn.TabIndex = 2;
            this.encriptBtn.Text = "encript message";
            this.encriptBtn.UseVisualStyleBackColor = true;
            this.encriptBtn.Click += new System.EventHandler(this.encriptBtn_Click);
            // 
            // decriptBtn
            // 
            this.decriptBtn.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.decriptBtn.Location = new System.Drawing.Point(623, 247);
            this.decriptBtn.Margin = new System.Windows.Forms.Padding(4);
            this.decriptBtn.Name = "decriptBtn";
            this.decriptBtn.Size = new System.Drawing.Size(308, 70);
            this.decriptBtn.TabIndex = 2;
            this.decriptBtn.Text = " decript message";
            this.decriptBtn.UseVisualStyleBackColor = true;
            this.decriptBtn.Click += new System.EventHandler(this.decriptBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(1000, 562);
            this.Controls.Add(this.decriptBtn);
            this.Controls.Add(this.encriptBtn);
            this.Controls.Add(this.originalTextBox);
            this.Controls.Add(this.encriptTextBox);
            this.Controls.Add(this.keyTextBox);
            this.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Encript app";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox keyTextBox;
        private System.Windows.Forms.RichTextBox encriptTextBox;
        private System.Windows.Forms.RichTextBox originalTextBox;
        private System.Windows.Forms.Button encriptBtn;
        private System.Windows.Forms.Button decriptBtn;
    }
}

